package org.gradle.wrapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.InputStream;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Small open-source bootstrap for this generated sample project.
 * Uses only the official https://services.gradle.org/distributions/gradle-8.9-bin.zip.
 * Replaces the unavailable official Gradle wrapper binary in the build environment.
 */
public final class GradleWrapperMain {
  public static void main(String[] args) throws Exception {
    final String version="8.9";
    final String distribution="https://services.gradle.org/distributions/gradle-"+version+"-bin.zip";
    Path home=Path.of(System.getProperty("user.home"),".gradle","lisuan-bootstrap");
    Path directory=home.resolve("gradle-"+version);
    boolean windows=System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
    Path command=directory.resolve("bin").resolve(windows?"gradle.bat":"gradle");
    if(!Files.exists(command)) {
      Files.createDirectories(home);
      Path zip=home.resolve("gradle-"+version+"-bin.zip");
      if(!Files.exists(zip)) {
        System.out.println("下载官方 Gradle "+version+"（首次构建需要联网）...");
        HttpClient client=HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS)
            .connectTimeout(java.time.Duration.ofSeconds(45)).build();
        HttpRequest req=HttpRequest.newBuilder(URI.create(distribution)).timeout(java.time.Duration.ofMinutes(8)).GET().build();
        HttpResponse<Path> res=client.send(req,HttpResponse.BodyHandlers.ofFile(zip));
        if(res.statusCode()!=200){Files.deleteIfExists(zip);throw new Exception("Gradle 下载失败：HTTP "+res.statusCode());}
      }
      System.out.println("解压官方 Gradle...");
      try(ZipInputStream zis=new ZipInputStream(Files.newInputStream(zip))) {
        ZipEntry item;
        byte[] buf=new byte[65536];
        while((item=zis.getNextEntry())!=null) {
          Path dest=home.resolve(item.getName()).normalize();
          if(!dest.startsWith(home))throw new Exception("zip 文件包含非法路径");
          if(item.isDirectory())Files.createDirectories(dest);
          else {
            Files.createDirectories(dest.getParent());
            try(java.io.OutputStream out=Files.newOutputStream(dest)){
              int n;while((n=zis.read(buf))!=-1)out.write(buf,0,n);
            }
          }
          zis.closeEntry();
        }
      }
      if(!Files.exists(command))throw new Exception("Gradle 文件解压不完整");
      if(!windows)command.toFile().setExecutable(true);
    }
    List<String> run=new ArrayList<>();
    if(windows){run.add("cmd");run.add("/c");}
    run.add(command.toAbsolutePath().toString());
    run.addAll(Arrays.asList(args));
    ProcessBuilder pb=new ProcessBuilder(run).inheritIO();
    Process p=pb.start();
    System.exit(p.waitFor());
  }
}
