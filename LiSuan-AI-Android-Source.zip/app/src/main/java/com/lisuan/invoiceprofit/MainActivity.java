package com.lisuan.invoiceprofit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * 安卓安装版：离线前端与固定计算引擎，无 Node/网站/中转服务器。
 * OpenAI Key 用 Android Keystore 加密，Java 原生 HTTPS 层添加认证。
 */
public class MainActivity extends Activity {
    private static final String URL_LOCAL = "file:///android_asset/public/index.html";
    private static final String ENDPOINT = "https://api.openai.com/v1/responses";
    private static final String KEY_ALIAS = "lisuan_ai_key_v1";
    private static final int PICK_IMAGE = 701;
    private static final int SAVE_CSV = 702;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private String awaitingCsv;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23,36,57));
        getWindow().setNavigationBarColor(Color.rgb(245,247,251));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(245,247,251));
        setContentView(web);
        WebSettings opts = web.getSettings();
        opts.setJavaScriptEnabled(true);
        opts.setDomStorageEnabled(true);
        opts.setAllowFileAccess(true);
        opts.setAllowContentAccess(true);
        opts.setJavaScriptCanOpenWindowsAutomatically(false);
        opts.setSupportMultipleWindows(false);
        opts.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        opts.setAllowUniversalAccessFromFileURLs(false);
        opts.setAllowFileAccessFromFileURLs(false);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri url = req.getUrl();
                String value = url.toString();
                if(value.startsWith("file:///android_asset/public/") || "about:blank".equals(value)) return false;
                if("https".equals(url.getScheme()) || "http".equals(url.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, url)); } catch(Exception ignored) { }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
                    picker.setType("image/*");
                    picker.addCategory(Intent.CATEGORY_OPENABLE);
                    picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    ContentValues info = new ContentValues();
                    info.put(MediaStore.Images.Media.DISPLAY_NAME, "发票_" + System.currentTimeMillis() + ".jpg");
                    info.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, info);
                    Intent selection = Intent.createChooser(picker, "选择发票照片（可多选）");
                    if(cameraUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        camera.setClipData(ClipData.newUri(getContentResolver(), "发票照片", cameraUri));
                        selection.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }
                    startActivityForResult(selection, PICK_IMAGE);
                    return true;
                } catch(Exception e) {
                    clearCamera();
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    toast("照片选择器无法启动：" + e.getMessage());
                    return false;
                }
            }
        });
        WebView.setWebContentsDebuggingEnabled(false);
        web.loadUrl(URL_LOCAL);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE) {
            ArrayList<Uri> chosen = new ArrayList<>();
            boolean captured = false;
            if(resultCode == RESULT_OK) {
                if(data != null && data.getClipData() != null) {
                    ClipData clips = data.getClipData();
                    for(int i=0;i<clips.getItemCount();i++) chosen.add(clips.getItemAt(i).getUri());
                } else if(data != null && data.getData() != null) {
                    chosen.add(data.getData());
                    captured = cameraUri != null && cameraUri.equals(data.getData());
                } else if(cameraUri != null) {
                    chosen.add(cameraUri);
                    captured = true;
                }
            }
            if(!captured) clearCamera();
            else cameraUri = null;
            if(fileCallback != null) {
                fileCallback.onReceiveValue(chosen.isEmpty() ? null : chosen.toArray(new Uri[0]));
                fileCallback = null;
            }
            return;
        }
        if(requestCode == SAVE_CSV) {
            String csv = awaitingCsv;
            awaitingCsv = null;
            if(resultCode == RESULT_OK && data != null && data.getData() != null && csv != null) {
                try(OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if(out == null) throw new Exception("无法创建文件");
                    out.write(csv.getBytes(StandardCharsets.UTF_8));
                    toast("CSV 已保存，可以用 Excel 打开");
                } catch(Exception e) { toast("保存文件失败：" + e.getMessage()); }
            }
        }
    }

    private void clearCamera() {
        if(cameraUri != null) {
            try { getContentResolver().delete(cameraUri,null,null); } catch(Exception ignored) { }
            cameraUri = null;
        }
    }
    private void toast(String message) { mainHandler.post(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show()); }
    private void js(String command) {
        mainHandler.post(()->{
            if(web != null && web.getUrl() != null && web.getUrl().startsWith("file:///android_asset/public/")) {
                web.evaluateJavascript(command,null);
            }
        });
    }
    private void returned(String id, boolean success, String response) {
        js("window.LisuanNative.onResponse(" + JSONObject.quote(id) + "," + success + "," + JSONObject.quote(response) + ");");
    }

    private SecretKey secretKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if(store.containsAlias(KEY_ALIAS)) return (SecretKey) store.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return generator.generateKey();
    }
    private synchronized void saveSecret(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey());
        byte[] ciphertext = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] iv = cipher.getIV();
        byte[] combined = new byte[iv.length + ciphertext.length];
        System.arraycopy(iv,0,combined,0,iv.length);
        System.arraycopy(ciphertext,0,combined,iv.length,ciphertext.length);
        getSharedPreferences("credentials",MODE_PRIVATE).edit()
                .putString("openai_key",Base64.encodeToString(combined,Base64.NO_WRAP)).apply();
    }
    private synchronized String loadSecret() {
        String encoded=getSharedPreferences("credentials",MODE_PRIVATE).getString("openai_key","");
        if(encoded == null || encoded.isEmpty()) return "";
        try {
            byte[] combined = Base64.decode(encoded,Base64.DEFAULT);
            if(combined.length < 29) return "";
            byte[] iv = java.util.Arrays.copyOfRange(combined,0,12);
            byte[] encrypted = java.util.Arrays.copyOfRange(combined,12,combined.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,secretKey(),new GCMParameterSpec(128,iv));
            return new String(cipher.doFinal(encrypted),StandardCharsets.UTF_8);
        } catch(Exception e) { return ""; }
    }

    private void settingsDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48,12,48,4);
        TextView note=new TextView(this);
        note.setText(loadSecret().isEmpty() ? "尚未配置密钥。填入 OpenAI API Key 即可使用发票识别。" : "密钥已加密保存。留空并保存可保持原密钥。\n密钥只保存在本机，不会上传到其他服务器。");
        note.setTextSize(14);
        note.setPadding(0,0,0,22);
        box.addView(note);
        EditText key=new EditText(this);
        key.setHint("sk-...");
        key.setSingleLine(true);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(key);
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("OpenAI API Key 设置")
                .setView(box)
                .setPositiveButton("保存",(d,w)->{
                    String val=key.getText().toString().trim();
                    if(val.isEmpty()) {toast("已保留原来的 API Key");return;}
                    if(!val.startsWith("sk-")){toast("API Key 格式似乎不正确，应该以 sk- 开头");return;}
                    try{saveSecret(val);toast("API Key 已加密保存");js("window.LisuanNative.onKeyChanged();");}
                    catch(Exception e){toast("保存密钥失败：" + e.getMessage());}
                })
                .setNeutralButton("删除密钥",(d,w)->{
                    getSharedPreferences("credentials",MODE_PRIVATE).edit().remove("openai_key").apply();
                    js("window.LisuanNative.onKeyChanged();");toast("已删除本机保存的 API Key");
                })
                .setNegativeButton("取消",(d,w)->{})
                .create();
        dialog.show();
    }

    private static String slurp(InputStream stream) throws Exception {
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] block=new byte[8192];int n;long size=0;
            while((n=in.read(block))!=-1){size+=n;if(size>20*1024*1024)throw new Exception("API 响应过大");out.write(block,0,n);}
            return out.toString("UTF-8");
        }
    }
    private void makeOpenAIRequest(String id, String body) {
        String key = loadSecret();
        if(key.isEmpty()){returned(id,false,"未设置 OpenAI API Key，请点击右上角设置");return;}
        HttpURLConnection connection=null;
        try {
            URL url=new URL(ENDPOINT);
            connection=(HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(140000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization","Bearer "+key);
            connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
            byte[] json=body.getBytes(StandardCharsets.UTF_8);
            if(json.length>68*1024*1024)throw new Exception("照片过大，请减少图片大小或张数");
            connection.setFixedLengthStreamingMode(json.length);
            try(OutputStream out=connection.getOutputStream()){out.write(json);}
            int status=connection.getResponseCode();
            InputStream stream=status<400?connection.getInputStream():connection.getErrorStream();
            String payload=stream==null?"":slurp(stream);
            if(status>=400) {
                String reason="接口错误：HTTP "+status;
                try{reason=new JSONObject(payload).getJSONObject("error").optString("message",reason);}catch(Exception ignored) { }
                if(status==401)reason="API Key 无效，请检查设置";
                if(status==429)reason="OpenAI API 额度不足或请求过于频繁，请稍后重试";
                returned(id,false,reason);
            } else returned(id,true,payload);
        } catch(Exception e){returned(id,false,"连接 OpenAI 失败：" + e.getMessage());}
        finally{if(connection!=null)connection.disconnect();}
    }

    private final class Bridge {
        @JavascriptInterface public boolean hasKey(){return !loadSecret().isEmpty();}
        @JavascriptInterface public void openSettings(){mainHandler.post(MainActivity.this::settingsDialog);}
        @JavascriptInterface public void request(String id,String requestJson){
            if(id==null||id.length()>50||requestJson==null){returned(String.valueOf(id),false,"请求格式不正确");return;}
            network.execute(()->makeOpenAIRequest(id,requestJson));
        }
        @JavascriptInterface public void copyText(String text){
            mainHandler.post(()->{
                ClipboardManager clip=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                if(clip!=null)clip.setPrimaryClip(ClipData.newPlainText("利算AI 商品价格",text));
                toast("商品售价已复制");
            });
        }
        @JavascriptInterface public void saveCsv(String csv){
            if(csv==null||csv.length()>2_000_000){toast("CSV 数据过大");return;}
            mainHandler.post(()->{
                awaitingCsv=csv;
                Intent action=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                action.addCategory(Intent.CATEGORY_OPENABLE);
                action.setType("text/csv");
                action.putExtra(Intent.EXTRA_TITLE,"利算AI_商品售价_"+java.time.LocalDate.now()+".csv");
                try{startActivityForResult(action,SAVE_CSV);}catch(Exception e){toast("无法打开保存窗口："+e.getMessage());}
            });
        }
    }
    @Override public void onBackPressed(){
        if(web!=null&&web.canGoBack())web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
        network.shutdownNow();
        if(web!=null){web.removeJavascriptInterface("AndroidBridge");web.destroy();web=null;}
        super.onDestroy();
    }
}
