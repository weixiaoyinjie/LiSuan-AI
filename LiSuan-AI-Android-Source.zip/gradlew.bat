@echo off
setlocal
set APP_HOME=%~dp0
set "JAVA_BIN=java"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_BIN=%JAVA_HOME%\bin\java.exe"
if "%JAVA_BIN%"=="java" if exist "%PROGRAMFILES%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_BIN=%PROGRAMFILES%\Android\Android Studio\jbr\bin\java.exe"
"%JAVA_BIN%" -cp "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
