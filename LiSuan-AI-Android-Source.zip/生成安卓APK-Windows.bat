@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在生成利算 AI 安卓安装包...
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo 构建未成功。请确认安装 Android Studio、SDK 35 以及 JDK 17。
  pause
  exit /b 1
)
echo.
echo APK 位于 app\build\outputs\apk\debug\app-debug.apk
pause
